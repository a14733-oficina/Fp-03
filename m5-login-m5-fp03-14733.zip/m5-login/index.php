<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <nav class="navbar navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="alunos_lista.php">Verificar acesso</a>
    </div>
  </nav>

  <main class="container py-4">
    <div class="row">
      <div class="col-12 col-lg-6 mx-auto">
        <div class="card shadow-sm">
          <div class="card-body">
            <h3 class="card-title mb-3">Verificar acesso</h3>
            <form action="verificar.php" method="POST" class="vstack gap-3">
              <div>
                <label class="form-label">Username</label>
                <input type="text" name="nome" class="form-control" required maxlength="100">
              </div>
              <div>
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required maxlength="150">
              </div>
              <div class="d-flex gap-2">
                <a class="btn btn-secondary" href="alunos_lista.php">Cancelar</a>
                <button class="btn btn-primary">Entrar</button>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  </main>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>