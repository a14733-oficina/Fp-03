<?php
require "conexao.php";

$username = "";
$password = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_POST['nome'] ?? '';
    $password = $_POST['password'] ?? '';

    $sql = "SELECT * FROM utilizadores WHERE username = :username AND password = :password";
    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);

    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        header("Location: ../m5-crud");
        exit;
    } else {
        header("Location: erro.php");
        exit;
    }
}
?>