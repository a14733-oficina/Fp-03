<?php
include "conexao.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id > 0){
  $stmt = $pdo->prepare("DELETE FROM produtos WHERE id=?");
  $stmt->execute([$id]);
}
header("Location: produtos_lista.php?ok=1");
exit;