<?php
include "conexao.php";
$stmt = $pdo->prepare("SELECT * FROM produtos ORDER BY id DESC");
$stmt->execute();
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Produtos - CRUD Inline</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <nav class="navbar navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="index.php">CRUD - Produtos (CRUD Inline)</a>
      <a class="btn btn-outline-light" href="produtos_form.php">+ Novo Produto</a>
    </div>
  </nav>

  <main class="container py-4">
    <div class="row">
      <div class="col-12 col-lg-10 mx-auto">
        <?php if(isset($_GET['ok'])): ?>
          <div class="alert alert-success">Operação concluída.</div>
        <?php endif; ?>
        <div class="card shadow-sm">
          <div class="card-body">
            <h3 class="card-title mb-3">Lista de Produtos</h3>
            <table class="table table-striped align-middle">
              <thead>
                <tr>
                  <th style="width:5%">#</th>
                  <th>Produto</th>
                  <th style="width:15%">Preço (€)</th>
                  <th class="text-end" style="width:20%">Ações</th>
                </tr>
              </thead>
              <tbody>
                <?php if(!$produtos): ?>
                  <tr><td colspan="4" class="text-center text-muted py-4">Sem produtos.</td></tr>
                <?php else: ?>
                  <?php foreach($produtos as $p): ?>
                    <tr>
                      <form action="produtos_editar.php" method="POST" class="row g-0 align-items-center">
                        <td class="col">
                          <?php echo htmlspecialchars($p['id']); ?>
                          <input type="hidden" name="id" value="<?php echo htmlspecialchars($p['id']); ?>">
                        </td>
                        <td class="col">
                          <input type="text" name="produto" class="form-control" value="<?php echo htmlspecialchars($p['produto']); ?>" required maxlength="100">
                        </td>
                        <td class="col">
                          <input type="number" step="0.01" min="0" name="preco" class="form-control" value="<?php echo htmlspecialchars($p['preco']); ?>" required>
                        </td>
                        <td class="col text-end">
                          <button class="btn btn-warning btn-sm">Guardar</button>
                          <a class="btn btn-danger btn-sm"
                             onclick="return confirm('Eliminar o produto #<?php echo htmlspecialchars($p['id']); ?>?');"
                             href="produtos_apagar.php?id=<?php echo htmlspecialchars($p['id']); ?>">
                            Eliminar
                          </a>
                        </td>
                      </form>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </main>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>