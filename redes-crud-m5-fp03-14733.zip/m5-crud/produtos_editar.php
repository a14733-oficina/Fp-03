<?php
include "conexao.php";
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$produto = isset($_POST['produto']) ? trim($_POST['produto']) : '';
$preco = isset($_POST['preco']) ? floatval($_POST['preco']) : 0;
if($id > 0 && $produto !== '' && $preco >= 0){
  $stmt = $pdo->prepare("UPDATE produtos SET produto=?, preco=? WHERE id=?");
  $stmt->execute([$produto, $preco, $id]);
}
header("Location: produtos_lista.php?ok=1");
exit;